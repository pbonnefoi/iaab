﻿/**
 * @license Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.html or http://ckeditor.com/license
 */

CKEDITOR.plugins.setLang( 'uicolor', 'no', {
	title: 'Fargevelger for brukergrensesnitt',
	preview: 'Forhåndsvisning i sanntid',
	config: 'Lim inn følgende tekst i din config.js-fil',
	predefined: 'Forhåndsdefinerte fargesett'
});
